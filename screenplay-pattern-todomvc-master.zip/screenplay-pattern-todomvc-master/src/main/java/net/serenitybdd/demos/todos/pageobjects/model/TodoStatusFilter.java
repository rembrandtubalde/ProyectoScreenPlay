package net.serenitybdd.demos.todos.pageobjects.model;


public enum TodoStatusFilter {
    All, Active, Completed
}
