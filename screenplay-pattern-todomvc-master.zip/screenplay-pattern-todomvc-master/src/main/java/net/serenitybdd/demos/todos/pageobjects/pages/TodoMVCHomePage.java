package net.serenitybdd.demos.todos.pageobjects.pages;

import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.annotations.DefaultUrl;

@DefaultUrl("http://todomvc.com/")
public class TodoMVCHomePage extends PageObject {}
