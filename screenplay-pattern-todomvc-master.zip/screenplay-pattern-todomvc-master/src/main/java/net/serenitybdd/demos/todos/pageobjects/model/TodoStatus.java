package net.serenitybdd.demos.todos.pageobjects.model;

public enum TodoStatus {
    Active, Completed
}