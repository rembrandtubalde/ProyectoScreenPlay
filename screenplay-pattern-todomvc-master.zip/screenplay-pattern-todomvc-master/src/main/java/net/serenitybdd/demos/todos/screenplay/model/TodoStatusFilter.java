package net.serenitybdd.demos.todos.screenplay.model;

public enum TodoStatusFilter {
    All, Active, Completed
}
