package net.serenitybdd.demos.todos.pageobjects.features.completing_todos;

import net.thucydides.core.annotations.Step;

public class ExampleSteps {

    @Step("Page should contain [{0}] [{1}] element(s)")
    public void pageShouldContainElements(Object value, Object name) {

    }
}